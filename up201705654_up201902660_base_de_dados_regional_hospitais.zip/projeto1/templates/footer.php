<footer>
      <p>Gabriel Castro &copy; Tatiana Machado, 2020</p>
    </footer>
  </body>
</html>
<!DOCTYPE html>
<html>
  <head>
    <title>Base de Dados Regional para Hospitais</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css"> 
    <link href="https://fonts.googleapis.com/css?family=Libre+Franklin|Merriweather" rel="stylesheet"> 
  </head>
  <body>
    <header>
      <h1><a href="pacinte.html">Base de Dados Regional para Hospitais</a></h1>
      <form>
        <input type="text" placeholder="name" name="name">
        <input type="password" placeholder="password" name="password">
        <input type="submit" value="Login">
      
      </form>
    </header>